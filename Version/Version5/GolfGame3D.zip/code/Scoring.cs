﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/**This is a .cs document that holds the total and current score variables for the game**/
public class Scoring : MonoBehaviour
{

    public static float totalScore = 0; //float variable meant to hold your total score in the game
    public static float currentScore = 0; //float variable meant to hold your score at your current holes
}
